ansible-playbook -i /root/playbook/inventory /usr/share/ansible/openshift-ansible/playbooks/byo/config.yml

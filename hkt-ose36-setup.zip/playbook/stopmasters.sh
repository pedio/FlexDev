ansible masters -i inventory -m service -a "name=atomic-openshift-master-api.service state=stopped"
ansible masters -i inventory -m service -a "name=atomic-openshift-master-controllers.service state=stopped"


ansible-playbook -i /root/playbook/inventory /root/playbook/enable-hardening.yaml

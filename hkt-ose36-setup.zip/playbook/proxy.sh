ansible all -i inventory -m shell -a "export http_proxy=172.25.2.6:8080"
ansible all -i inventory -m shell -a "export https_proxy=172.25.2.6:8080"

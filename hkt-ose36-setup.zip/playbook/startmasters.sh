ansible masters -i inventory -m service -a "name=atomic-openshift-master-api.service state=started"
ansible masters -i inventory -m service -a "name=atomic-openshift-master-controllers.service state=started"


ansible-playbook -i /root/playbook/inventory /usr/share/ansible/openshift-ansible/playbooks/byo/openshift-cluster/openshift-metrics.yml \
   -e openshift_metrics_install_metrics=True \
   -e openshift_metrics_storage_kind=nfs \
   -e openshift_metrics_storage_access_modes=['ReadWriteOnce'] \
   -e openshift_metrics_hawkular_hostname=hawkular-metrics.apps.osm.pccw.com \
   -e openshift_metrics_storage_host=RHNFS01.osm.pccw.com \
   -e openshift_metrics_storage_nfs_directory=/exports \
   -e openshift_metrics_storage_volume_name=metrics \
   -e openshift_metrics_storage_volume_size=10Gi


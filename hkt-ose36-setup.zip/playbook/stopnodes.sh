ansible nodes -i inventory -m service -a "name=atomic-openshift-node.service state=stopped"

